package com.amrita.jpl.cys21021.prac;

/**
 * The Main class is the entry point of the program.
 * It prints "Hello world!" to the console.
 */
public class hello_world {
    /**
     * The main method is the entry point of the program.
     * It prints "Hello world!" to the console.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}
